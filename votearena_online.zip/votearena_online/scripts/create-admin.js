require("dotenv").config();
const bcrypt = require("bcryptjs");
const { Pool } = require("pg");
(async () => {
  if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required");
  const email = String(process.env.ADMIN_EMAIL || "").trim().toLowerCase();
  const password = String(process.env.ADMIN_PASSWORD || "");
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error("Set ADMIN_EMAIL to a valid email address.");
  if (password.length < 14 || password.length > 72) throw new Error("Set ADMIN_PASSWORD to a unique password with 14–72 characters.");
  const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.PGSSL === "true" ? { rejectUnauthorized: true } : undefined });
  try {
    const hash = await bcrypt.hash(password, 12);
    await pool.query(`
      CREATE TABLE IF NOT EXISTS users (
        id BIGSERIAL PRIMARY KEY, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL,
        role TEXT NOT NULL DEFAULT 'voter' CHECK (role IN ('voter','admin')), created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )`);
    await pool.query(
      `INSERT INTO users(email,password_hash,role) VALUES($1,$2,'admin')
       ON CONFLICT(email) DO UPDATE SET password_hash=EXCLUDED.password_hash, role='admin'`,
      [email, hash]
    );
    console.log(`Admin account ready: ${email}`);
  } finally { await pool.end(); }
})().catch(e => { console.error(e.message); process.exit(1); });
