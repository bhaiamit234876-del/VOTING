# VoteArena Online

A Node.js + Express + PostgreSQL starter for an online public-opinion poll. It includes registered voter accounts, hashed passwords, admin-only candidate management, photo uploads, one vote per account enforced by a database unique constraint, and vote totals/percentages.

## Requirements
- Windows 10/11
- Node.js 20 or newer
- PostgreSQL 15 or newer (local) or a managed PostgreSQL database
- Internet access for online deployment

## Run locally on Windows

1. Install Node.js LTS from https://nodejs.org/ (keep “Add to PATH” enabled).
2. Install PostgreSQL from https://www.postgresql.org/download/windows/ and remember the database password.
3. Open pgAdmin or SQL Shell (psql). Create a database named `votearena`.
   - In pgAdmin: right-click Databases → Create → Database → name `votearena`.
4. Extract this ZIP into a folder such as `C:\\votearena-online`.
5. Open Command Prompt in that folder (File Explorer address bar → type `cmd` → Enter).
6. Run `npm install`.
7. Copy `.env.example` to `.env`. Edit `.env` and set `DATABASE_URL` to your local PostgreSQL user/password/database. Example:
   `DATABASE_URL=postgres://postgres:YOUR_PASSWORD@localhost:5432/votearena`
8. Generate a secret by running:
   `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`
   Copy the output into `SESSION_SECRET` in `.env`. Keep `NODE_ENV=development` and `TRUST_PROXY=false` locally.
9. Create an admin account. In the same Command Prompt, set environment variables for this one command:
   - Command Prompt:
     `set ADMIN_EMAIL=you@example.com`
     `set ADMIN_PASSWORD=Use-A-Unique-Long-Password-Here`
     `npm run create-admin`
   - Use a unique password at least 14 characters long. Do not use the example password.
10. Start the website: `npm start`
11. Open http://localhost:3000. Create a normal voter account with “Create account”. Sign in as your admin email/password and open “Manage candidates”.

The app creates its database tables automatically on first startup. PostgreSQL must be running before `npm start`.

## Put it online for everyone (example: Render + managed PostgreSQL)

1. Create a private Git repository and upload this project source. Do NOT commit `.env`, real passwords, or database credentials. `.gitignore` excludes `.env`.
2. Create a managed PostgreSQL database with your hosting provider. Copy its internal connection URL.
3. Create a web service from the repository:
   - Build command: `npm install`
   - Start command: `npm start`
   - Runtime: Node 20+
4. Add environment variables in the hosting dashboard:
   - `NODE_ENV=production`
   - `DATABASE_URL` = managed database URL
   - `SESSION_SECRET` = a new random secret (32+ characters)
   - `TRUST_PROXY=true` only if the provider terminates HTTPS at its trusted proxy
   - `MAX_UPLOAD_MB=3`
   - If the database requires SSL and your provider documents it, configure `PGSSL=true` or follow that provider's PostgreSQL connection instructions.
5. After the first deploy, open the provider's shell/console and create the admin. Set `ADMIN_EMAIL` and `ADMIN_PASSWORD` in the service environment, then run `npm run create-admin`. Remove the `ADMIN_PASSWORD` environment variable afterward. If the platform has no shell, run the script from your own computer with the production `DATABASE_URL` set securely; do not paste credentials into public chat or source control.
6. Attach a persistent disk for the `uploads` directory or, preferably, change photo storage to a managed object-storage service. Many free hosting filesystems are temporary and photos can disappear on redeploy.
7. Use the provider's HTTPS URL, test signup/login/voting/admin and review provider logs. Keep dependencies updated and back up the database.

## Important limitations and security notes

- This is a practical starter, not a certified election platform or a security audit.
- One vote per registered account is enforced by a PostgreSQL UNIQUE constraint. It does not stop people from creating multiple accounts. Email verification, anti-bot controls, and stronger identity checks may be needed.
- Votes are associated with user accounts in the database. This is NOT a secret ballot. Do not collect sensitive political preferences unless you have a suitable privacy/legal basis and protections.
- Results are public. Candidate names, descriptions, vote totals, and percentages are shown to all visitors.
- Candidate deletion is blocked when votes exist to preserve result integrity. A production system should support archiving and audit logs.
- Photo upload checks MIME type and size but is not a complete malware/content validation system. For a public production service, add image re-encoding, malware scanning, moderation, and object storage.
- Session cookies are HTTP-only and secure in production, sessions are stored in PostgreSQL, passwords use bcrypt, requests use CSRF tokens and same-origin checks, and login/signup/vote routes are rate limited. Still obtain a professional security review before high-stakes use.
- The admin creator script promotes/updates the account matching `ADMIN_EMAIL` to admin. Protect the database and hosting dashboard.
- This is an unofficial public opinion poll, not an official election service. Do not use it for government elections, legal decisions, or high-stakes voting without appropriate authorization and independent review.
