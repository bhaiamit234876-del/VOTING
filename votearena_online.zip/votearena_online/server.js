require("dotenv").config();
const express = require("express");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const session = require("express-session");
const pgSession = require("connect-pg-simple")(session);
const { Pool } = require("pg");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const multer = require("multer");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const isProd = process.env.NODE_ENV === "production";
if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL is required. Copy .env.example to .env and configure PostgreSQL.");
if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) throw new Error("SESSION_SECRET must be a random string of at least 32 characters.");
if (isProd && process.env.TRUST_PROXY !== "true") {
  console.warn("WARNING: On most hosted HTTPS platforms, set TRUST_PROXY=true only when behind that platform's trusted proxy.");
}
if (process.env.TRUST_PROXY === "true") app.set("trust proxy", 1);

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.PGSSL === "true" ? { rejectUnauthorized: true } : undefined
});
pool.on("error", err => console.error("Unexpected PostgreSQL pool error", err));

const uploadDir = path.join(__dirname, "uploads");
fs.mkdirSync(uploadDir, { recursive: true });
const maxUploadBytes = Math.max(1, Number(process.env.MAX_UPLOAD_MB || 3)) * 1024 * 1024;
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, uploadDir),
  filename: (_req, file, cb) => cb(null, crypto.randomUUID() + path.extname(file.originalname).toLowerCase())
});
const upload = multer({
  storage,
  limits: { fileSize: maxUploadBytes, files: 1 },
  fileFilter: (_req, file, cb) => {
    if (!["image/jpeg", "image/png", "image/webp", "image/gif"].includes(file.mimetype)) {
      return cb(new Error("Upload a JPG, PNG, WEBP, or GIF image."));
    }
    cb(null, true);
  }
});

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: {
  directives: {
    defaultSrc: ["'self'"],
    imgSrc: ["'self'", "data:"],
    styleSrc: ["'self'", "'unsafe-inline'"],
    scriptSrc: ["'self'"],
    upgradeInsecureRequests: isProd ? [] : null
  }
}}));
app.use(express.urlencoded({ extended: false, limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public"), { maxAge: isProd ? "1h" : 0 }));
app.use("/uploads", express.static(uploadDir, { maxAge: isProd ? "1d" : 0, dotfiles: "deny", index: false }));

app.use(session({
  store: new pgSession({ pool, tableName: "user_sessions", createTableIfMissing: true }),
  name: "votearena.sid",
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure: isProd,
    sameSite: "lax",
    maxAge: 1000 * 60 * 60 * 8
  }
}));

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: "draft-7", legacyHeaders: false, message: "Too many attempts. Wait 15 minutes and try again." });
const signupLimiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 8, standardHeaders: "draft-7", legacyHeaders: false });
const voteLimiter = rateLimit({ windowMs: 60 * 60 * 1000, limit: 20, standardHeaders: "draft-7", legacyHeaders: false });

app.use(async (req, res, next) => {
  try {
    res.locals.user = null;
    res.locals.csrfToken = req.session.csrfToken || (req.session.csrfToken = crypto.randomBytes(32).toString("hex"));
    res.locals.notice = req.session.notice || null;
    delete req.session.notice;
    if (req.session.userId) {
      const result = await pool.query("SELECT id, email, role FROM users WHERE id=$1", [req.session.userId]);
      if (result.rows[0]) res.locals.user = result.rows[0];
      else req.session.userId = null;
    }
    next();
  } catch (e) { next(e); }
});

function flash(req, message) { req.session.notice = message; }
function requireAuth(req, res, next) {
  if (!res.locals.user) { flash(req, "Please sign in first."); return req.session.save(() => res.redirect("/login")); }
  next();
}
function requireAdmin(req, res, next) {
  if (!res.locals.user || res.locals.user.role !== "admin") {
    res.status(403).render("error", { title: "Access denied", message: "Only an administrator can manage candidates." });
    return;
  }
  next();
}
function verifyCsrf(req, res, next) {
  const submitted = req.body && req.body._csrf;
  if (!submitted || !req.session.csrfToken || !crypto.timingSafeEqual(Buffer.from(String(submitted)), Buffer.from(String(req.session.csrfToken)))) {
    return res.status(403).render("error", { title: "Request expired", message: "This form expired or could not be verified. Go back, refresh the page, and try again." });
  }
  // Browser-origin check provides an extra layer; requests without Origin are allowed for normal form navigation.
  const origin = req.get("origin");
  if (origin) {
    const expected = `${req.protocol}://${req.get("host")}`;
    if (origin !== expected) return res.status(403).render("error", { title: "Request blocked", message: "This request came from an unexpected origin." });
  }
  next();
}

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id BIGSERIAL PRIMARY KEY,
      email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'voter' CHECK (role IN ('voter','admin')),
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS candidates (
      id BIGSERIAL PRIMARY KEY,
      name VARCHAR(100) NOT NULL,
      description VARCHAR(250) NOT NULL DEFAULT '',
      photo_path TEXT NOT NULL DEFAULT '',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS votes (
      id BIGSERIAL PRIMARY KEY,
      user_id BIGINT NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
      candidate_id BIGINT NOT NULL REFERENCES candidates(id) ON DELETE RESTRICT,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE INDEX IF NOT EXISTS votes_candidate_id_idx ON votes(candidate_id);
  `);
}

app.get("/", async (req, res, next) => {
  try {
    const result = await pool.query(`
      SELECT c.id, c.name, c.description, c.photo_path,
             COUNT(v.id)::int AS votes
      FROM candidates c LEFT JOIN votes v ON v.candidate_id=c.id
      GROUP BY c.id ORDER BY c.id
    `);
    const total = result.rows.reduce((sum, c) => sum + c.votes, 0);
    const voted = res.locals.user ? (await pool.query("SELECT 1 FROM votes WHERE user_id=$1", [res.locals.user.id])).rowCount > 0 : false;
    res.render("index", { candidates: result.rows, total, voted });
  } catch (e) { next(e); }
});

app.get("/signup", (req, res) => res.render("auth", { mode: "signup" }));
app.post("/signup", signupLimiter, verifyCsrf, async (req, res, next) => {
  try {
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) return res.status(400).render("error", { title: "Check your details", message: "Enter a valid email address." });
    if (password.length < 12 || password.length > 72) return res.status(400).render("error", { title: "Check your password", message: "Use a password between 12 and 72 characters." });
    const hash = await bcrypt.hash(password, 12);
    const result = await pool.query("INSERT INTO users(email,password_hash,role) VALUES($1,$2,'voter') RETURNING id", [email, hash]);
    req.session.regenerate(err => {
      if (err) return next(err);
      req.session.userId = result.rows[0].id;
      req.session.csrfToken = crypto.randomBytes(32).toString("hex");
      req.session.save(err2 => err2 ? next(err2) : res.redirect("/"));
    });
  } catch (e) {
    if (e.code === "23505") return res.status(409).render("error", { title: "Account already exists", message: "An account with that email already exists. Please sign in." });
    next(e);
  }
});

app.get("/login", (req, res) => res.render("auth", { mode: "login" }));
app.post("/login", loginLimiter, verifyCsrf, async (req, res, next) => {
  try {
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    const result = await pool.query("SELECT id,password_hash FROM users WHERE email=$1", [email]);
    const valid = result.rows[0] && await bcrypt.compare(password, result.rows[0].password_hash);
    if (!valid) return res.status(401).render("error", { title: "Sign-in failed", message: "Email or password is incorrect." });
    const id = result.rows[0].id;
    req.session.regenerate(err => {
      if (err) return next(err);
      req.session.userId = id;
      req.session.csrfToken = crypto.randomBytes(32).toString("hex");
      req.session.save(err2 => err2 ? next(err2) : res.redirect("/"));
    });
  } catch (e) { next(e); }
});

app.post("/logout", verifyCsrf, (req, res, next) => {
  req.session.destroy(err => {
    if (err) return next(err);
    res.clearCookie("votearena.sid", { httpOnly: true, secure: isProd, sameSite: "lax" });
    res.redirect("/");
  });
});

app.post("/vote/:id", requireAuth, voteLimiter, verifyCsrf, async (req, res, next) => {
  const candidateId = Number(req.params.id);
  if (!Number.isSafeInteger(candidateId) || candidateId < 1) return res.status(400).render("error", { title: "Invalid candidate", message: "Choose a valid candidate." });
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const candidate = await client.query("SELECT id FROM candidates WHERE id=$1", [candidateId]);
    if (!candidate.rowCount) {
      await client.query("ROLLBACK");
      return res.status(404).render("error", { title: "Candidate not found", message: "This candidate no longer exists." });
    }
    await client.query("INSERT INTO votes(user_id,candidate_id) VALUES($1,$2)", [res.locals.user.id, candidateId]);
    await client.query("COMMIT");
    flash(req, "Your vote has been recorded.");
    req.session.save(() => res.redirect("/"));
  } catch (e) {
    await client.query("ROLLBACK");
    if (e.code === "23505") return res.status(409).render("error", { title: "Already voted", message: "Each account can vote once in this poll." });
    next(e);
  } finally { client.release(); }
});

app.get("/results", async (req, res, next) => {
  try {
    const result = await pool.query(`
      SELECT c.id,c.name,c.description,c.photo_path,COUNT(v.id)::int AS votes
      FROM candidates c LEFT JOIN votes v ON v.candidate_id=c.id
      GROUP BY c.id ORDER BY votes DESC,c.name ASC
    `);
    const total = result.rows.reduce((sum, c) => sum + c.votes, 0);
    res.render("results", { candidates: result.rows, total });
  } catch (e) { next(e); }
});

app.get("/admin", requireAuth, requireAdmin, async (req, res, next) => {
  try {
    const result = await pool.query(`
      SELECT c.id,c.name,c.description,c.photo_path,COUNT(v.id)::int AS votes
      FROM candidates c LEFT JOIN votes v ON v.candidate_id=c.id
      GROUP BY c.id ORDER BY c.id
    `);
    res.render("admin", { candidates: result.rows });
  } catch (e) { next(e); }
});

app.post("/admin/candidates", requireAuth, requireAdmin, verifyCsrf, upload.single("photo"), async (req, res, next) => {
  try {
    const name = String(req.body.name || "").trim();
    const description = String(req.body.description || "").trim();
    if (!name || name.length > 100 || description.length > 250) {
      if (req.file) fs.unlink(req.file.path, () => {});
      return res.status(400).render("error", { title: "Invalid candidate details", message: "Name is required (up to 100 characters); description must be 250 characters or fewer." });
    }
    const photo = req.file ? "/uploads/" + req.file.filename : "";
    await pool.query("INSERT INTO candidates(name,description,photo_path) VALUES($1,$2,$3)", [name, description, photo]);
    flash(req, "Candidate added.");
    res.redirect("/admin");
  } catch (e) { if (req.file) fs.unlink(req.file.path, () => {}); next(e); }
});

app.post("/admin/candidates/:id", requireAuth, requireAdmin, verifyCsrf, upload.single("photo"), async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const name = String(req.body.name || "").trim();
    const description = String(req.body.description || "").trim();
    if (!Number.isSafeInteger(id) || id < 1 || !name || name.length > 100 || description.length > 250) {
      if (req.file) fs.unlink(req.file.path, () => {});
      return res.status(400).render("error", { title: "Invalid candidate details", message: "Check the candidate ID, name, and description." });
    }
    const old = await pool.query("SELECT photo_path FROM candidates WHERE id=$1", [id]);
    if (!old.rowCount) {
      if (req.file) fs.unlink(req.file.path, () => {});
      return res.status(404).render("error", { title: "Candidate not found", message: "This candidate no longer exists." });
    }
    const photo = req.file ? "/uploads/" + req.file.filename : old.rows[0].photo_path;
    await pool.query("UPDATE candidates SET name=$1,description=$2,photo_path=$3 WHERE id=$4", [name, description, photo, id]);
    if (req.file && old.rows[0].photo_path.startsWith("/uploads/")) fs.unlink(path.join(uploadDir, path.basename(old.rows[0].photo_path)), () => {});
    flash(req, "Candidate updated.");
    res.redirect("/admin");
  } catch (e) { if (req.file) fs.unlink(req.file.path, () => {}); next(e); }
});

app.post("/admin/candidates/:id/delete", requireAuth, requireAdmin, verifyCsrf, async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const old = await pool.query("SELECT photo_path FROM candidates WHERE id=$1", [id]);
    if (!old.rowCount) return res.status(404).render("error", { title: "Candidate not found", message: "This candidate no longer exists." });
    const votes = await pool.query("SELECT COUNT(*)::int AS count FROM votes WHERE candidate_id=$1", [id]);
    if (votes.rows[0].count > 0) return res.status(409).render("error", { title: "Candidate has votes", message: "Candidates with recorded votes cannot be deleted, so results stay auditable. Hide or archive them in a future version instead." });
    await pool.query("DELETE FROM candidates WHERE id=$1", [id]);
    if (old.rows[0].photo_path.startsWith("/uploads/")) fs.unlink(path.join(uploadDir, path.basename(old.rows[0].photo_path)), () => {});
    flash(req, "Candidate deleted.");
    res.redirect("/admin");
  } catch (e) { next(e); }
});

app.get("/health", (_req, res) => res.json({ status: "ok" }));
app.use((err, req, res, next) => {
  console.error(err);
  if (err instanceof multer.MulterError) {
    const message = err.code === "LIMIT_FILE_SIZE" ? `Photo is too large. Maximum size is ${process.env.MAX_UPLOAD_MB || 3} MB.` : "Photo upload failed.";
    return res.status(400).render("error", { title: "Upload problem", message });
  }
  if (err.message && err.message.startsWith("Upload a JPG")) return res.status(400).render("error", { title: "Unsupported photo", message: err.message });
  res.status(500).render("error", { title: "Something went wrong", message: isProd ? "An unexpected error occurred. Please try again later." : err.message });
});

initDb().then(() => app.listen(PORT, () => console.log(`VoteArena running on http://localhost:${PORT}`)))
  .catch(err => { console.error("Database initialization failed:", err); process.exit(1); });
